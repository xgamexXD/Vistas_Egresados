

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Agregar Estudiante</h1>

        <!-- Agregar enctype para subir archivos -->
        <form action="<?php echo e(route('students.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">Nombre:</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" class="form-control" required>
            </div>
<br>
            <!-- Campo para subir la imagen -->
            <div class="form-group">
                <label for="imagen"><lb> Imagen:</lb> </label>
                <input type="file" name="imagen" class="form-control-file">
            </div>
<br>
            <button type="submit" class="btn btn-primary">Agregar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tws\PROYECTO2\resources\views/students/create.blade.php ENDPATH**/ ?>