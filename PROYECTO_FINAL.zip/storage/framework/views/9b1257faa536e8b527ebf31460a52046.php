<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Lista de Estudiantes</h2>

    <!-- Mostrar el rol del usuario autenticado -->
    <div class="mb-3">
        <strong>Rol: </strong>
        <span class="badge 
            <?php if(Auth::user()->role == 'administrador'): ?> 
                bg-danger 
            <?php elseif(Auth::user()->role == 'director'): ?> 
                bg-primary 
            <?php elseif(Auth::user()->role == 'profesor'): ?> 
                bg-secondary 
            <?php else: ?> 
                bg-light text-dark 
            <?php endif; ?>">
            <?php echo e(Auth::user()->role); ?>

        </span>
    </div>

    <!-- Mensajes de éxito -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Mostrar el botón de agregar solo para administrador y director -->
    <?php if(Auth::user()->role == 'administrador' || Auth::user()->role == 'director'): ?>
        <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary mb-3">Agregar Estudiante</a>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Imagen</th> <!-- Columna para la imagen -->
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student->name); ?></td>
                    <td><?php echo e($student->email); ?></td>
                    
                    <td style="text-align: left;">
                            <?php if($student->imagen): ?>
                                <img src="data:image/PNG;base64,<?php echo e(base64_encode($student->imagen)); ?>" alt="Imagen de <?php echo e($student->name); ?>" style="width: 80px; height: auto;">
                            <?php else: ?>
                                <p>No disponible</p>
                            <?php endif; ?>
                        </td>
                    <td>
                        <!-- Mostrar opciones de editar y eliminar según el rol -->
                        <?php if(Auth::user()->role == 'administrador'): ?>
                            <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-warning btn-sm">Editar</a>

                            <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        <?php elseif(Auth::user()->role == 'director'): ?>
                            <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tws\PROYECTO2\resources\views\home.blade.php ENDPATH**/ ?>