<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use Illuminate\Support\Facades\Storage;

class StudentController extends Controller
{
    // Mostrar la lista de estudiantes
    public function index()
    {
        // Obtener los estudiantes de la base de datos
        $students = Student::all();
        
        // Retorna la vista 'home' con la variable 'students'
        return view('home', ['students' => $students]);
    }

    public function showStudents()
{
    $students = Student::all(); // Consulta para obtener todos los estudiantes
    return view('plantilla', compact('students')); // Enviar los datos a la vista
}


    // Mostrar el formulario para crear un estudiante
    public function create()
    {
        return view('students.create');
    }

    // Almacenar un nuevo estudiante
    public function store(Request $request)
    {
        // Validar los datos de entrada, incluyendo la imagen
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:students,email',
            'imagen' => 'nullable|image|max:2048', // Validar que la imagen sea opcional, que sea una imagen y no supere los 2MB
        ]);

        // Crear un nuevo estudiante
        $student = new Student();
        $student->name = $request->input('name');
        $student->email = $request->input('email');

        if ($request->hasFile('imagen')) {
            $student->imagen = file_get_contents($request->file('imagen'));

        }

        $student->save();

        return redirect()->route('students.index')->with('success', 'Estudiante agregado exitosamente.');
    }


    // Mostrar el formulario para editar un estudiante
    public function edit($id)
    {
        $student = Student::findOrFail($id);
        return view('students.edit', compact('student'));
    }

    // Actualizar un estudiante existente
    public function update(Request $request, $id)
    {
        // Validar los datos de entrada, incluyendo la imagen
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:students,email,' . $id,
            'imagen' => 'nullable|image|max:2048', // Validar que la imagen sea opcional y no supere los 2MB
        ]);

        $student = Student::findOrFail($id);
        $student->name = $request->input('name');
        $student->email = $request->input('email');

        // Manejar la imagen
    if ($request->hasFile('imagen')) {
        $student->imagen = file_get_contents($request->file('imagen')->getRealPath());
    }

    // Guardar los cambios
    $student->save();

        return redirect()->route('students.index')->with('success', 'Estudiante actualizado exitosamente.');
    }

    // Eliminar un estudiante
    public function destroy($id)
    {
        $student = Student::findOrFail($id);

        // Eliminar la imagen del almacenamiento si existe
        if ($student->imagen) {
            Storage::disk('public')->delete($student->imagen);
        }

        $student->delete();

        return redirect()->route('students.index')->with('success', 'Estudiante eliminado exitosamente.');
    }
}
