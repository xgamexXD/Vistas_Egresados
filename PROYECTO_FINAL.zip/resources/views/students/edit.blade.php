@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Estudiante</h1>

        <!-- Agregar enctype para subir archivos -->
        <form action="{{ route('students.update', $student->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label for="name">Nombre:</label>
                <input type="text" name="name" value="{{ $student->name }}" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" value="{{ $student->email }}" class="form-control" required>
            </div>

            <!-- Mostrar la imagen actual si existe -->
            <div class="form-group">
                <label for="imagen_actual">Imagen actual:</label><br>
                @if ($student->imagen)
                    <img src="{{ asset('storage/' . $student->imagen) }}" alt="Imagen actual" width="150">
                @else
                    <p>No hay imagen cargada</p>
                @endif
            </div>

            <!-- Campo para subir una nueva imagen -->
            <div class="form-group">
                <label for="imagen">Cambiar imagen:</label>
                <input type="file" name="imagen" class="form-control-file">
            </div>

            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
