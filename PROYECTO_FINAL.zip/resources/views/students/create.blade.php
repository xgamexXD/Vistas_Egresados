@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Agregar Estudiante</h1>

        <!-- Agregar enctype para subir archivos -->
        <form action="{{ route('students.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label for="name">Nombre:</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" class="form-control" required>
            </div>
<br>
            <!-- Campo para subir la imagen -->
            <div class="form-group">
                <label for="imagen"><lb> Imagen:</lb> </label>
                <input type="file" name="imagen" class="form-control-file">
            </div>
<br>
            <button type="submit" class="btn btn-primary">Agregar</button>
        </form>
    </div>
@endsection
