@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Lista de Estudiantes</h2>
    
    <!-- Mensajes de éxito -->
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <!-- Mostrar el botón de agregar solo para administrador, profesor y director -->
    @if (Auth::user()->role == 'administrador' || Auth::user()->role == 'profesor' || Auth::user()->role == 'director')
        <a href="{{ route('students.create') }}" class="btn btn-primary mb-3">Agregar Estudiante</a>
    @endif

    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach($students as $student)
                <tr>
                    <td>{{ $student->name }}</td>
                    <td>{{ $student->email }}</td>
                    <td>
                        <!-- Mostrar opciones de editar y eliminar solo para administrador y director -->
                        @if (Auth::user()->role == 'administrador' || Auth::user()->role == 'director')
                            <a href="{{ route('students.edit', $student->id) }}" class="btn btn-warning btn-sm">Editar</a>

                            <form action="{{ route('students.destroy', $student->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
